import NathanEvans.FileReader;
import org.junit.Test;
import static org.junit.Assert.*;

public class FileReaderTests {

    @Test
    public void wordCountTest(){
        int wordsTest = FileReader.wordCount("textFiles/text.txt");
        assertEquals(9,wordsTest);
    }

    @Test
    public void blankWordTest(){
        int wordTest3 = FileReader.wordCount("textFiles/blank.txt");
        assertEquals(0,wordTest3);
    }

    @Test
    public void lineCountTest(){
        int lineCount1 = FileReader.numberOfLines("textFiles/text.txt");
        assertEquals(3,lineCount1);
    }

    @Test
    public void lineBlankTest(){
        int lineCount = FileReader.numberOfLines("textFiles/blank.txt");
        assertEquals(0,lineCount);
    }

    @Test
    public void linesWithNonAlphabeticChars(){
        int lineCount = FileReader.numberOfLines("textFiles/linesWithNonAlphabeticChars.txt");
        assertEquals(5,lineCount);
    }

    @Test
    public void commonLetterTest(){
        char freqLetter = FileReader.mostCommonLetter("textFiles/text.txt");
        assertEquals('e',freqLetter);
    }

    @Test
    public void commonLetterWithPuncuation(){
        char freqLetter = FileReader.mostCommonLetter("textFiles/oneLetter.txt");
        assertEquals('e',freqLetter);
    }

    @Test
    public void commonLetterBlank(){
        char freqLetter = FileReader.mostCommonLetter("textFiles/blank.txt");
        assertEquals(' ',freqLetter);
    }

    @Test
    public void averageLetterTest(){
        double averageLetter = FileReader.averageLettersPerWord("textFiles/text.txt");
        assertEquals(4.0,averageLetter,0.01);
    }

    @Test
    public void averageLetterBlank(){
        double averageLetter = FileReader.averageLettersPerWord("textFiles/blank.txt");
        assertEquals(0.0,averageLetter,0.01);
    }

    @Test
    public void wrongFileName(){
        int FileNotFound = FileReader.numberOfLines("file.txt");
        assertEquals(0, FileNotFound);
    }

}
